import "materialize-css/sass/materialize.scss";
import { Application } from "../../globular-mvc/Application";
import { ApplicationView } from "../../globular-mvc/ApplicationView";
import { Account } from "../../globular-mvc/Account";
import { SettingsMenu, SettingsPanel } from "../../globular-mvc/components/Settings"

export class MediaApplicationView extends ApplicationView {

  /** The settings Menu */
  protected MediaSettingsMenu: SettingsMenu;

  /** The settings Panel */
  protected MediaSettingsPanel: SettingsPanel;

  constructor() {
    super();
    this.MediaSettingsMenu = new SettingsMenu();
    this.MediaSettingsPanel = new SettingsPanel();
  }

  onLogin(account: Account) {
    super.onLogin(account);
    
    // fire the window resize event to display the side menu.
    window.dispatchEvent(new Event('resize'));
  }

  onLogout() {
    super.onLogout();
    this.getWorkspace().innerHTML = "";
    this.MediaSettingsMenu.clear(); // clear various stuff...
    this.MediaSettingsPanel.clear();
  }
}

export class MediaApplication extends Application {
  constructor(view: MediaApplicationView) {
    super("media", "Globular Media", view);
  }
}
