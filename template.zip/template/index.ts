import "./css/main.css";
import { MediaApplication, MediaApplicationView } from "./src/application";

/**
 * The main entry point of an applicaition.
 */
function main() {

  let view = new MediaApplicationView();

  // The application.
  let application = new MediaApplication(view);

  // Connected to the backend.
  application.init(
    window.location.origin + "/config",
    () => {

    },
    (err: any) => {
      console.log(err);
    }
  );
}

/**
 * The main function will be call a the end of document initialisation.
 */
document.addEventListener("DOMContentLoaded", function (event) {

  main();
});
